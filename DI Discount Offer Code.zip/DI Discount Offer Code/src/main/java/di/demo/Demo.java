package di.demo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import di.Card;

public class Demo {

	public static void main(String[] args) {
		
		ApplicationContext ctn = new ClassPathXmlApplicationContext("application_context.xml");
		Card card = (Card) ctn.getBean("ccard");
		card.details();
		
		Card card1 = (Card) ctn.getBean("dcard");
		card1.details();
		
		((AbstractApplicationContext)ctn).close();
	}

}
