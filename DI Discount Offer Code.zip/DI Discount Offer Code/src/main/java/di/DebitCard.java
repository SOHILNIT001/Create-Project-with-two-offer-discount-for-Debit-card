package di;

public class DebitCard implements Card {
	Offer off;

	public DebitCard(Offer off) {
		this.off = off;
		off.offer = "Summer Sale";
	}

	public void details() {
		System.out.println("This is Debit Card");
		off.print();
	}

}
