package di;

public class Offer {

	public String offer;

	public void print() {
		System.out.println("value of offer in Offer class : " + offer);
	}
}
